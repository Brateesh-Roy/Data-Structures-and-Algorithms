public class SearchEngine {
    InvertedPageIndex IPI;
    MyLinkedList<PageEntry> PEntryList;
    public SearchEngine(){
        InvertedPageIndex newIPI=new InvertedPageIndex();
        MyLinkedList<PageEntry> newPEntryList=new MyLinkedList<>();
        IPI=newIPI;
        PEntryList=newPEntryList;
    }
    public PageEntry findpage(String name){
        Node<PageEntry> temp=PEntryList.header.next;
        while (temp.next!=null){
            if(temp.data.pagename.equals(name))
                return temp.data;
            temp=temp.next;
        }

        return null;
    }
    void performAction(String actionMessage){
        //System.out.println("starting "+actionMessage);
        String actionMessageBreakdown[]=actionMessage.split(" ");
        if(actionMessageBreakdown[0].equals("addPage")){
            String newpagename=actionMessageBreakdown[1];
            PageEntry newpageentry=new PageEntry(newpagename);
            PEntryList.insertRear(newpageentry);
            IPI.addPage(newpageentry);
        }
        if(actionMessageBreakdown[0].equals("queryFindPagesWhichContainWord")){
            String reqword=actionMessageBreakdown[1].toLowerCase();
            MySet<PageEntry> reqset=IPI.getPagesWhichContainWord(reqword);
            Node<PageEntry> temp=reqset.clcn.header.next;
            if (!reqset.clcn.isEmpty()) {
                String printout = "";
                while (temp.next.next != null) {
                    printout = printout + temp.data.pagename + ", ";
                    temp = temp.next;
                }
                printout = printout + temp.data.pagename;
                System.out.println(printout);
            }
            else System.out.println("No webpage contains word "+actionMessageBreakdown[1] );
        }
        if(actionMessageBreakdown[0].equals("queryFindPositionsOfWordInAPage")){
            String reqword=actionMessageBreakdown[1].toLowerCase();
            String reqpagename=actionMessageBreakdown[2];
            PageEntry p=findpage(reqpagename);
            if (p==null){
                System.out.println("Webpage not found.");
            }
            else {
                System.out.println(reqword);
                System.out.println(p.pagename);
                String printout = "";
                Node<WordEntry> temp = p.pageIndex.wordEntries.header.next;
                while (temp.next != null) {
                    if (temp.data.Word.equals(reqword)) {
                        System.out.println("found");
                        break;
                    }
                    temp = temp.next;
                }
                if (temp.next == null) {
                    System.out.println("Webpage " + reqpagename + " does not contain word " + reqword);
                    return;
                }
                if (temp.data.Word.equals(reqword)) {
                    Node<Position> tempsec = temp.data.getAllPositionsForThisWord().header.next;
                    while (tempsec.next.next != null) {
                        printout = printout + tempsec.data.wordIndex + ", ";
                        tempsec = tempsec.next;
                    }
                    printout = printout + tempsec.data.wordIndex;
                    System.out.println(printout);
                } else {
                    System.out.println("Webpage " + reqpagename + " does not contain word " + reqword);
                }
            }
        }
        //System.out.println("ending "+actionMessage);
    }
}
