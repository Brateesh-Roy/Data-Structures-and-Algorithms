public class WordEntry {
    String Word;
    MyLinkedList<Position> allPositionsForThisWord;
    public WordEntry(String word){
        Word=word;
        MyLinkedList<Position> p=new MyLinkedList<>();
        allPositionsForThisWord=p;
    }
    public void addPosition(Position position){
        allPositionsForThisWord.insertRear(position);
    }
    public void addPositions(MyLinkedList<Position> positions){
        Node<Position> splicehead=allPositionsForThisWord.trailer.prev;
        Node<Position> splicetail=allPositionsForThisWord.trailer;
        Node<Position> joinhead=positions.header.next;
        Node<Position> jointail=positions.trailer.prev;
        joinhead.prev=splicehead;
        jointail.next=splicetail;
        splicehead.next=joinhead;
        splicetail.prev=jointail;
    }
    public MyLinkedList<Position> getAllPositionsForThisWord(){
        return allPositionsForThisWord;
    }
    public float getTermFrequency(String reqpagename){
        int termFrequency=0;
        Node<Position> temp=allPositionsForThisWord.header.next;
        while (temp.next!=null){
            if(temp.data.p.pagename.equals(reqpagename)){
                termFrequency=termFrequency+1;
            }
            temp=temp.next;
        }
        return termFrequency;
    }
}
