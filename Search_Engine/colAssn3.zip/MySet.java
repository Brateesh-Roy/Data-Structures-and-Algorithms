public class MySet <X> {
    public MyLinkedList<X> clcn=new MyLinkedList<>();

    public boolean IsMember(X element){
        if(!clcn.isEmpty()){
            Node<X> p=clcn.header.next;
            while (p.next!=null){
                if(p.data.equals(element)){
                    return true;
                }
                p=p.next;
            }
            if (p==clcn.trailer)
                return false;
            return true;
        }
        else
            return false;
    }
    void addElement(X element){
        if(!IsMember(element))
            clcn.insertRear(element);
    }
    public MySet<X> union (MySet<X> otherset){
        MySet <X> Unionset=new MySet<>();
        Node<X> traveller=clcn.header.next;
        while (!traveller.data.equals(null)){
            Unionset.clcn.insertRear(traveller.data);
            traveller=traveller.next;
        }
        traveller=otherset.clcn.header.next;
        while (traveller.data.equals(null)){
            if(!IsMember(traveller.data)){
                Unionset.clcn.insertRear(traveller.data);
            }
            traveller=traveller.next;
        }
        return Unionset;
    }
    public MySet<X> intersection(MySet<X> otherSet){
        MySet<X> Intersectionset=new MySet<>();
        Node<X> traveller=clcn.header.next;
        while (traveller.data.equals(null)){
            if(otherSet.IsMember(traveller.data)){
                Intersectionset.clcn.insertRear(traveller.data);
            }
            traveller=traveller.next;
        }
        return Intersectionset;
    }
}
