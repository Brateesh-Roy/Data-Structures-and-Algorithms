import java.io.*;
import java.util.Scanner;

public class PageEntry {
    MyLinkedList<String> stopWords;
    MyLinkedList<Integer> punctuations ;

    String modifiedPage;
    String pagename;
    PageIndex pageIndex;

    public PageEntry(String pageName) {
        MyLinkedList<String> sW = new MyLinkedList<>();
        MyLinkedList<Integer> punct = new MyLinkedList<>();
        String mpage=new String();
        PageIndex pi=new PageIndex();
        stopWords = sW;
        punctuations = punct;
        modifiedPage=mpage;
        pagename = pageName;
        pageIndex=pi;
        punctuations.insertRear(123);
        punctuations.insertRear(125);
        punctuations.insertRear(91);
        punctuations.insertRear(93);
        punctuations.insertRear(60);
        punctuations.insertRear(62);
        punctuations.insertRear(61);
        punctuations.insertRear(40);
        punctuations.insertRear(41);
        punctuations.insertRear(46);
        punctuations.insertRear(44);
        punctuations.insertRear(59);
        punctuations.insertRear(58);
        punctuations.insertRear(39);
        punctuations.insertRear(45);
        punctuations.insertRear(33);
        punctuations.insertRear(63);
        punctuations.insertRear(35);
        punctuations.insertRear(34);
        stopWords.insertRear("a");
        stopWords.insertRear("an");
        stopWords.insertRear("the");
        stopWords.insertRear("they");
        stopWords.insertRear("these");
        stopWords.insertRear("this");
        stopWords.insertRear("for");
        stopWords.insertRear("is");
        stopWords.insertRear("are");
        stopWords.insertRear("was");
        stopWords.insertRear("of");
        stopWords.insertRear("or");
        stopWords.insertRear("and");
        stopWords.insertRear("does");
        stopWords.insertRear("will");
        stopWords.insertRear("whose");
        try {
            FileInputStream fstream = new FileInputStream("webpages/" + pageName);
            Scanner s = new Scanner(fstream);
            String pageprocessor = new String();
            while (s.hasNext()) {
                pageprocessor = pageprocessor + s.nextLine()+" ";
            }
            int i = 0;
            int temp;
            while (i < pageprocessor.length()) {
                temp = pageprocessor.charAt(i);
                if (punctuations.IsMember(temp)) {
                    modifiedPage = modifiedPage + " ";
                } else {
                    modifiedPage = modifiedPage + pageprocessor.charAt(i);
                }
                i=i+1;
            }
            modifiedPage = modifiedPage.toLowerCase();
            String wordarray[] = modifiedPage.trim().split(" +");
            int j = 0;
            while (j < wordarray.length) {
                if (!stopWords.IsMember(wordarray[j])) {
                    Position p = new Position(this, j + 1);
                    pageIndex.addPositionForWord(wordarray[j], p);
                }
                j=j+1;
            }
        }
        catch (FileNotFoundException e){
            System.out.println("File not found.");
        }
    }
    PageIndex getPageIndex() {
        return pageIndex;
    }
}
