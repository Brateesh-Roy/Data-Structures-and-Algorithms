public class InvertedPageIndex {
    MyHashTable hashTable=new MyHashTable();
    public void addPage(PageEntry p){
        Node<WordEntry> temp=p.pageIndex.getWordEntries().header.next;
        while (temp.next!=null) {
            hashTable.addPositionsForWord(temp.data);
            temp=temp.next;
        }
    }
    public MySet<PageEntry> getPagesWhichContainWord(String str){
        return hashTable.pagesWhichContainWord(str);
    }
}
